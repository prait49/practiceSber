package org.example.lordOfTheRing.Unit.MiddleEarthUnit;


import org.example.lordOfTheRing.Unit.AbstractUnit;

public class WoodenElf extends AbstractUnit implements MiddleEarthUnit {


    public WoodenElf(String name) {
        super(name, 6, 6);
    }
}
