package org.example.lordOfTheRing.Unit.MiddleEarthUnit;

import org.example.lordOfTheRing.Unit.Cavalry.AbstractCavalryUnit;
import org.example.lordOfTheRing.Unit.Cavalry.Mount;

class Human extends AbstractCavalryUnit<Mount.Horse> implements MiddleEarthUnit {

    public Human(String name) {
        super(name, 7, 8, Mount.Horse);
    }


}
