package org.example.lordOfTheRing.Unit;

public interface Unit {

}




