package org.example.lordOfTheRing.Unit.Cavalry;

import org.example.lordOfTheRing.Unit.AbstractUnit;


public abstract class AbstractCavalryUnit<T extends Mount> extends AbstractUnit implements Cavalry {
    protected T mount;

    public AbstractCavalryUnit(String name, int minPower, int maxPower, T mount) {
        super(name, minPower, maxPower);
        this.mount = mount;
    }
    @Override
    public int getPower() {
        return super.getPower() + mount.getPower();
    }


    public <T extends AbstractUnit, T2 extends Mount> void strike(T unit, T2 mount) {
        int targetPower = unit.getPower() + mount.getPower();
        targetPower = Math.max(targetPower - this.power, 0);
        unit.power = targetPower;
    }
}


