package org.example.lordOfTheRing.Unit;

import org.example.lordOfTheRing.Unit.Cavalry.Mount;

import java.util.Random;

 public abstract class AbstractUnit {

    protected String name;
    public int power;

    public AbstractUnit(String name, int minPower, int maxPower) {
        setName(name);
        this.power = new Random().nextInt(maxPower - minPower + 1) + minPower;
    }



    public int getPower() {
        return power;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = (name == null||name.trim().isEmpty()) ? super.toString()
                : name;
    }

    public boolean isAlive() {
        return power > 0;
    }
     public <T extends AbstractUnit, T2 extends Mount> void strike(T unit, T2 mount) {
         int targetPower = unit.power+ mount.getPower();
         targetPower = Math.max(targetPower - this.power, 0);
         unit.power = targetPower;
     }
     public void reducePower(int amount) {
         power = Math.max(power - amount, 0);
     }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " " + name + " has power " + power;
    }


}
