package org.example.lordOfTheRing.Unit.MordorUnit;

import org.example.lordOfTheRing.Unit.AbstractUnit;

import java.util.Random;

public class Troll extends AbstractUnit implements MordorUnit {


    public Troll(String name) {
        super(name, 11, 15);
    }
}
