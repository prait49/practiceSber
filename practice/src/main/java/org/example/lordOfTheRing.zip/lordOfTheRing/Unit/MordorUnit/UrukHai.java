package org.example.lordOfTheRing.Unit.MordorUnit;

import java.util.Random;

public class UrukHai extends Orc implements MordorUnit{

    public UrukHai(String name) {
        super(name);
    }

}
