package org.example.lordOfTheRing.Unit.MordorUnit;

import org.example.lordOfTheRing.Unit.AbstractUnit;

import java.util.Random;

public class Goblin extends AbstractUnit implements MordorUnit{

    public Goblin(String name) {
        super(name, 2, 5);
    }
}
