package org.example.lordOfTheRing.Unit.MiddleEarthUnit;

class Rohhirim  extends Human implements MiddleEarthUnit {
    public Rohhirim(String name) {
        super(name);
    }
}
