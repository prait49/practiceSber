package org.example.lordOfTheRing.Unit.Cavalry;

import org.example.lordOfTheRing.Unit.Unit;

public interface Cavalry extends Unit{


}