package org.example.lordOfTheRing.Unit.Infantry;

import org.example.lordOfTheRing.Unit.Unit;

public interface Infantry extends Unit {

}
