package com.intellekta.generics.middleearth.lordOfTheRing.Unit;

public interface MiddleEarthUnit extends Unit {

}
