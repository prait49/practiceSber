package com.intellekta.generics.middleearth.lordOfTheRing.Unit;

public class MiddleEarthUnit extends Unit {
    public MiddleEarthUnit(String name) {
        super(name);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
