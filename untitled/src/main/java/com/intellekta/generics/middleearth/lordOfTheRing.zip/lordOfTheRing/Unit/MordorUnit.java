package com.intellekta.generics.middleearth.lordOfTheRing.Unit;

public interface MordorUnit extends Unit {

}
