package com.intellekta.generics.middleearth.lordOfTheRing.Unit;

public class Infantry extends Unit{

    public Infantry(String name) {
        super(name);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
