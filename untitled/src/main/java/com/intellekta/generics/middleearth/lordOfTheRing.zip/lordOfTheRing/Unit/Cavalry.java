package com.intellekta.generics.middleearth.lordOfTheRing.Unit;

public interface Cavalry extends Unit{

}
