package com.intellekta.generics.middleearth.lordOfTheRing.Unit;

public class Cavalry extends Unit{
    public Cavalry(String name) {
        super(name);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
